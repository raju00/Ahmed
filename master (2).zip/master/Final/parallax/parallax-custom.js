//parallax
// if (jQuery().parallax){}
jQuery('#sec_').parallax("50%",0.4); 



jQuery('#intro').parallax("50%",0.3); 
jQuery('#swag').parallax("50%",0.4); 
 
